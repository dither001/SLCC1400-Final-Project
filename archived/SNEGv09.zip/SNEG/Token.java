/****************************************
* Last edit: 4/19/2017
* 
* Represents player-collectible objects
* and location-placed objects
****************************************/

import java.util.ArrayList;
import java.util.Collections;

public class Token {
   enum TokenType {ARTIFACT, ASSET, CONDITION, GATE, CLUE, MONSTER, SKILL, SPELL, TICKET}
   enum AssetType {ALLY, ITEM, SERV, TRINKET}
   enum AssetSubtype {MAGICAL, TOME, WEAPON} // TODO - FINISH LIST
   enum ConditionType {BANE, BOON, DEAL, INJURY, MADNESS} // TODO - FINISH LIST
   enum SpellType {INCANTATION, RITUAL}
   
   // fields
   private static Engine engine = new Engine();
   
   private String name = "Token";
   private boolean hasReckoning = false;
   private int locationID;
   public TokenType type;
   public AssetType assetType;
   public AssetType assetSubtype;
   public ConditionType conditionType;
   public SpellType spellType;
   
   // constructors
   public Token() {
      this(null);
   }
   
   public Token(TokenType type) {
      this(type, null);
   }
   
   public Token(TokenType type, String name) {
      this(type, name, 0);
   }
   
   public Token(TokenType type, String name, int loc) {
      this(type, null, name, loc);
   }
   
   
   public Token(TokenType type, AssetType assetType, String name) {
      this(type, assetType, name, 0);
   }
   
   public Token(TokenType type, AssetType assetType, String name, int loc) {
      this.type = type;
      this.assetType = assetType;
      this.name = name;
      locationID = loc;
   }
   
   
   /****************************************
   * Card Shuffler
   ****************************************/
   public static void moveIndexUp(ArrayList<Token> list)     {Collections.rotate(list, -1);}
   public static void tokenShuffle(ArrayList<Token> list)    {Collections.shuffle(list);}
   
   /****************************************
   * Clue tokens
   ****************************************/
   public void cluesInit(ArrayList<Token> list) {
      for (int i = 1; i <= 36; ++i) {
         list.add(new Token(Token.TokenType.CLUE, "Clue", i));
      }
      tokenShuffle(list);
   }
   
   /****************************************
   * Gate tokens
   ****************************************/
   public void gatesInit(ArrayList<Token> list) {
      list.add(new Token(Token.TokenType.GATE, "San Francisco", 22));
      list.add(new Token(Token.TokenType.GATE, "Arkham", 23));
      list.add(new Token(Token.TokenType.GATE, "Buenos Aires", 24));
      list.add(new Token(Token.TokenType.GATE, "London", 25));
      list.add(new Token(Token.TokenType.GATE, "Rome", 26));
      list.add(new Token(Token.TokenType.GATE, "Istanbul", 27));
      list.add(new Token(Token.TokenType.GATE, "Shanghai", 28));
      list.add(new Token(Token.TokenType.GATE, "Tokyo", 29));
      list.add(new Token(Token.TokenType.GATE, "Sydney", 30));
      tokenShuffle(list);
   }
   
   /****************************************
   * Monster tokens
   ****************************************/
   public void monsterInit(ArrayList<Token> list) {
      for (int i = 1; i <= 34; ++i) {
         list.add(new Token(Token.TokenType.MONSTER, "Monster", i));
      }
   }
   
   /****************************************
   * Assets, Artifacts, Conditions
   ****************************************/
   public void itemsInit(ArrayList<Token> list) {
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Cultes des Goules")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "De Vermis Mysteriis")); // TOME
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Flute of the Outer Gods")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Gate Box")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Glass of Mortlan")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Grotesque Statue"));
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Lightning Gun")); // WEAPON, MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Mi-go Brain Case")); // MAGICAL, TEAMWORK
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Necronomicon")); // TOME
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Pallid Mask")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Ruby of R'lyeh")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "The Silver Key")); // MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "Sword of Saint Jerome")); // WEAPON, MAGICAL
      list.add(new Token(Token.TokenType.ARTIFACT, Token.AssetType.ITEM, "T'tka Halot")); // TOME
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Arcane Scholar", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Cat Burglar", 1));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Hired Muscle", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Lodge Researcher", 3));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Personal Assistant", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Private Investigator", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Urban Guide", 4));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Vatican Missionary", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ALLY, "Witch Doctor", 3));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, ".38 Revolver", 1)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, ".45 Automatic", 2)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Arcane Manuscripts", 1)); // TOME
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Arcane Tome", 3)); // TOME
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Axe", 2)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Bandages", 1));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Bull Whip", 1)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Carbine Rifle", 3)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Double-Barreled Shotgun", 4)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Dynamite", 3)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Fine Clothes", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Fishing Net", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Holy Cross", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Holy Water", 2)); // MAGICAL
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Kerosene", 1));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "King James Bible", 2)); // TOME
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Protective Amulet", 1));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Spirit Dagger", 2)); // WEAPON, MAGICAL
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.ITEM, "Whiskey", 1));
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Agency Quarantine", 4));
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Charter Flight", 1));
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Delivery Service", 1)); //TEAMWORK
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Private Care", 2));
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Sanctuary", 2));
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Silver Twilight Ritual", 3));
//       list.add(new Token(Token.TokenType.ASSET, Token.AssetType.SERVICE, "Wireless Report", 1)); //TEAMWORK
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.TRINKET, ".18 Derringer", 1)); // WEAPON
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.TRINKET, "Lucky Cigarette Case", 2));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.TRINKET, "Lucky Rabbit's Foot", 1));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.TRINKET, "Pocket Watch", 1));
      list.add(new Token(Token.TokenType.ASSET, Token.AssetType.TRINKET, "Puzzle Box", 3));
      tokenShuffle(list);
   }
   
   public String getName() {return name;}
   public TokenType getType() {return type;}
   public static int getID(Token token) {return token.locationID;}
   
   public static Token getToken(ArrayList<Token> list, int index) {return list.get(index);}
   
   public void setLoc(int newLoc)      {locationID = newLoc;}
   
   @Override
   public String toString() {
      return "" + type + "\\" + getName() + "\\" + locationID;
   }
   
   /****************************************
   * Spawn gates & clues
   ****************************************/
   public static boolean tokenSpawn(Location[] places, 
                           ArrayList<Token> list,
                           int number) {
      
      int index;
      Location place;
      ArrayList<Token> destination;
      boolean placedToken = false;
      
      for (int i = 1; i <= number; ++i) {
         index = getID(getToken(list, 0));
         place = places[index];
         destination = place.getInventory();
         placedToken = tokenMove(list, destination);
         moveIndexUp(list);
      }
      
      return placedToken;
   }
   
   public static void awardThisClue() {
      Investigator[] people = Engine.getPeople();
      Investigator person = people[Engine.getLead()];
      Location place = Location.getPlace(Engine.getBoard(), Location.getLocation());
      tokenMove(place.getInventory(), person.getInventory());
      moveIndexUp(place.getInventory());
   }
   
   public static void clueGain() {
      Investigator[] people = Engine.getPeople();
      Investigator person = people[Engine.getLead()];
      tokenMove(Engine.getClueDeck(), person.getInventory());
      moveIndexUp(engine.getClueDeck());
   }
   
   /****************************************
   * Transfer tokens between inventories
   ****************************************/
   public static boolean tokenMove(ArrayList<Token> origin, ArrayList<Token> target) {
      boolean success = false;
      if (origin.isEmpty() != true) {
         target.add(origin.remove(0));
         success = true;
      }
      
      return success;
   }
}