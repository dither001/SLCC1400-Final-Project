/****************************************
* Last edit: 4/22/2017
* 
* represents mythos cards
****************************************/

import java.util.ArrayList;

public class Mythos {
   // fields
   enum MythosType {GREEN, AMBER, BLUE}
   
   private static int omen = 0;
   private static int OMEN_MAX = 3;
   private static int doomCounter = 15;
   
   private static DiceRoller dice;
   private static TextWrap wrap;
   private String name = "";
   private String text = "";
   public MythosType mythos;
   
   // constructors
   public Mythos(DiceRoller dice, TextWrap wrap) {
      this.dice = dice;
      this.wrap = wrap;
   }
   
   // methods
   public int getDoom() {return doomCounter;}
   
   public static int updateOmen() {
      ++omen;
      omen = (omen > OMEN_MAX) ? 0 : omen;
      
      // ISTANBUL, SAN_FRANCISCO ... green comet
      // BUENOS_AIRES, LONDON, TOKYO ... constellation
      // ARKHAM, ROME, SHANGHAI, SYDNEY ... green comet
      
      return omen;
   }
   
   public static void drawMythos(int turns, Location[] places,
                           Investigator[] people, int leader,
                           ArrayList<Token> clues, ArrayList<Token> gates) {
      Token clue = clues.get(0);
      Token gate = gates.get(0);
      switch (turns) {
         // stage 1
         case 1: // green
            updateOmen();
            clue.tokenSpawn(places, clues, 1);
            break;
         case 2: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 3: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 4: // blue
            break;
         
         // stage 2
         case 5: // green
            updateOmen();
            clue.tokenSpawn(places, clues, 1);
            break;
         case 6: // green
            updateOmen();
            clue.tokenSpawn(places, clues, 1);
            break;
         case 7: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 8: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 9: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 10: // blue
            break;
         
         // stage 3
         case 11: // green
            updateOmen();
            clue.tokenSpawn(places, clues, 1);
            break;
         case 12: // green
            updateOmen();
            clue.tokenSpawn(places, clues, 1);
            break;
         case 13: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 14: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 15: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         case 16: // amber
            updateOmen();
            gate.tokenSpawn(places, gates, 1);
            break;
         default: break;
      }
   }
   
   // end of code
}