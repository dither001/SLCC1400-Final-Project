/****************************************
* Last edit: 4/22/2017
* 
* produces various menus used in play
****************************************/

import java.util.Scanner;

public class Menu {
   // fields
   private static final Scanner input = new Scanner(System.in);
   private int charaMenu = 0;
   
   // constructors
   
   /****************************************
   * Resuable methods
   ****************************************/
   
   // prevents user from entering non-integer values
   public static void preventNonInteger() {
      while (!input.hasNextInt()) {
         input.next();
      }
   }
   
   // pauses output until user presses ENTER key
   public static void pressEnter() {
      System.out.printf("%n%nPress <ENTER> to continue.");
      try {System.in.read();}
      catch(Exception e){}
   }
   
   /****************************************
   * Investigator selection
   ****************************************/
   public static int investigatorSelect(Investigator[] people) {
      Investigator person;
      String name;
      String title;
      int i = 1;
      
      System.out.printf("%nActive investigators:");
      for (Investigator el : people) {
         person = el;
         name = person.getName();
         title = person.getTitle();
         // print name and title with proper spacing
         if    (i < 10) {System.out.printf("%n%d.  %s, %s", i, name, title);}
         else           {System.out.printf("%n%d. %s, %s", i, name, title);}
         // spacing between name and stats
//          for (int j = 0; j < 18 - (name.length() + title.length()); ++j) {System.out.printf(" ");}
         // print stats
//          System.out.printf("{%d, %d} {%d, %d, %d, %d, %d}",
//                person.getHealth(), person.getSanity(),
//                person.getLor(), person.getInf(), person.getObs(),
//                person.getStr(), person.getWil());
         ++i;
      }
      System.out.printf("%n");
      
      // input validation
      int choice;
      do {
         System.out.printf("%nChoose an investigator (1-12): ");
         preventNonInteger();
         choice = input.nextInt() - 1;
      } while (choice < 0 || choice >= people.length);
      
      person = people[choice];
      name = person.getName();
      title = person.getTitle();
      System.out.printf("%nYou have chosen %s, %s.", name, title);
      
      return choice;
   }
   
   /****************************************
   * Travel Agent
   ****************************************/
   public static int travelMenu(Location[] places, int index) {
      Location here = places[index];
      System.out.printf("%nYou are in %s.", here.getName(places, index));
      int[] placesToGo = here.getDestinations(places, index);
      int numOptions = here.numDestinations(places, index);
      
      int i = 1;
      System.out.printf("%nTravel Destinations:");
      for (int el : here.getDestinations(places, index)) {
         System.out.printf("%n%d. %s", i, here.getName(places,el));
         ++i;
      }
      System.out.printf("%n");
      
      int choice;
      do {
         System.out.printf("%nChoose a destination (0 to return): ");
         preventNonInteger();
         choice = input.nextInt() - 1;
      } while (choice >= numOptions);
      
      if (choice < 0) return index;
      int destination = placesToGo[choice];
      
      return destination;
   }
   
   
   // end of code
}