/****************************************
* Last edit: 4/22/2017
* 
* produces various menus used in play
****************************************/

import java.util.ArrayList;
import java.util.Scanner;

public class Menu {
   // fields
   private static final Scanner input = new Scanner(System.in);
   private int charaMenu = 0;
   
   /****************************************
   * Resuable methods
   ****************************************/
   
   // prevents user from entering non-integer values
   public static void preventNonInteger() {
      while (!input.hasNextInt()) {
         input.next();
      }
   }
   
   // pauses output until user presses ENTER key
   public static void pressEnter() {
      System.out.printf("%n%nPress <ENTER> to continue.");
      try {System.in.read();}
      catch(Exception e){}
   }
   
   /****************************************
   * Investigator selection
   ****************************************/
   public static int investigatorSelect(Investigator[] people) {
      Investigator person;
      String name;
      String title;
      int i = 1;
      
      System.out.printf("%nActive investigators:");
      for (Investigator el : people) {
         person = el;
         name = person.getName();
         title = person.getTitle();
         // print name and title with proper spacing
         if    (i < 10) {System.out.printf("%n%d.  %s, %s", i, name, title);}
         else           {System.out.printf("%n%d. %s, %s", i, name, title);}
         // spacing between name and stats
//          for (int j = 0; j < 18 - (name.length() + title.length()); ++j) {System.out.printf(" ");}
         // print stats
//          System.out.printf("{%d, %d} {%d, %d, %d, %d, %d}",
//                person.getHealth(), person.getSanity(),
//                person.getLor(), person.getInf(), person.getObs(),
//                person.getStr(), person.getWil());
         ++i;
      }
      System.out.printf("%n");
      
      // input validation
      int choice;
      do {
         System.out.printf("%nChoose an investigator (1-12): ");
         preventNonInteger();
         choice = input.nextInt() - 1;
      } while (choice < 0 || choice >= people.length);
      
      person = people[choice];
      name = person.getName();
      title = person.getTitle();
      System.out.printf("%nYou have chosen %s, %s.", name, title);
      
      return choice;
   }
   
   /****************************************
   * Action menu
   ****************************************/
   public static void actionMenu() {
      Location[] places = Engine.getBoard();
      int index = Location.getLocation();
      Location here = places[index];
      
      int n = 1;
      // series of menu options behind selection statements
      // if a menu option populates, index increments
      System.out.printf("%n======== ======== ======== ======== ");
      System.out.printf("%n%s", here.getName(places, index));
      System.out.printf("%n======== ======== ======== ======== ");
      
      System.out.printf("%n%d. Read Newspaper (no action)", n);
      int newsOption = n;
      ++n;
      System.out.printf("%n%d. Check Notebook (no action)", n);
      int noteOption = n;
      ++n;
      System.out.printf("%n%d. Travel", n);
      int travelOption = n;
      ++n;
      System.out.printf("%n%d. Rest", n);
      int restOption = n;
      //++n;
      
      int choice;
      do {
         System.out.printf("%nHow do you spend the week: ");
         preventNonInteger();
         choice = input.nextInt();
      } while (choice < 1 || choice > n);
      
      if (choice == newsOption) newspaper();
      else if (choice == noteOption) notebook();
      else if (choice == travelOption) Location.updateLocation(travelMenu());
      else if (choice == restOption) restAction();
      
   }
   
   /****************************************
   * Newspaper
   ****************************************/
   public static void newspaper() {
      Location[] places = Engine.getBoard();
      Location here = places[Location.getLocation()];
      
      System.out.printf("%n");
      System.out.printf("%n======== ==== Week %2d ==== ========", Engine.getTurns());
      System.out.printf("%n%s Newspaper", here.getName());
      System.out.printf("%n======== ======== ======== ======== ");
      System.out.printf("%nHoroscope: %s", omenCheck());
      System.out.printf("%nYour lucky number is: %d", Mythos.getDoom());
      System.out.printf("%n");
      System.out.printf("%nHeadlines: ");
      printHeadlines();
      pressEnter();
   }
   
   public static String omenCheck() {
      switch (Mythos.getOmen()) {
         case 0: return "Comet seen on horizon.";
         case 1: return "The stars are right.";
         case 2: return "Unseasonal eclipse.";
         case 3: return "The stars are right.";
         default: return "Too cloudy for reading.";
      }
   }
   
   public static void printHeadlines() {
      Location[] places = Engine.getBoard();
      ArrayList<Token> inventory;
      boolean printed = false;
      
      for(Location el : places) {
         inventory = el.getInventory();
         //if (printed == true) System.out.printf("%n");
         printed = false;
         // checks for presence of gate
         for (Token em : inventory) {
            if (em.type == Token.TokenType.GATE) {cityGates(el); printed = true; continue;}
         }
         // checks for presence of monster
         for (Token em : inventory) {
            if (em.type == Token.TokenType.MONSTER) {cityMonsters(el); printed = true; continue;}
         }
      }
      // end of headlines
   }
   
   public static void cityGates(Location place) {
      switch (place.city) {
            case ARKHAM: 
            case BUENOS_AIRES: 
            case ISTANBUL: 
            case LONDON: 
            case ROME: 
            case SHANGHAI: 
            case SAN_FRANCISCO: 
            case SYDNEY: 
            case TOKYO: System.out.printf("%nStrange weather over %s", place.getName());
            default: break;
         }
   }
   
   public static void cityMonsters(Location place) {
      switch (place.city) {
            case ARKHAM: 
            case BUENOS_AIRES: 
            case ISTANBUL: 
            case LONDON: 
            case ROME: 
            case SHANGHAI: 
            case SAN_FRANCISCO: 
            case SYDNEY: 
            case TOKYO: System.out.printf("%nPolice baffled by grisly murders!");
            default: break;
         }
   }
   
   /****************************************
   * Notebook
   ****************************************/
   public static void notebook() {
      Investigator[] people = Engine.getPeople();
      Investigator person = people[Engine.getLead()];
      
      System.out.printf("%n0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0-0");
      System.out.printf("%n-------- -------- -------- --------");
      System.out.printf("%n%s's Notebook", person.getName());
      System.out.printf("%n======== ======== ======== ========");
      
      System.out.printf("%nHealth: %d/%d", person.getHealth(), person.health());
      if (person.getHealth() < 3) {System.out.printf(" (consider resting)");}
      System.out.printf("%nSanity: %d/%d", person.getSanity(), person.sanity());
      if (person.getSanity() < 3) {System.out.printf(" (consider resting)");}
      
      System.out.printf("%n%nTo Do:");
      System.out.printf("%nCollect clues: %d/4", cluesCarried());
      
      System.out.printf("%n%nCurrent Leads:");
      printLeads();
      
      pressEnter();
   }
   
   public static void printLeads() {
      Location[] places = Engine.getBoard();
      ArrayList<Token> inventory;
      boolean printed = false;
      
      for(Location el : places) {
         inventory = el.getInventory();
         //if (printed == true) System.out.printf("%n");
         printed = false;
         // checks for presence of clue
         for (Token em : inventory) {
            if (em.type == Token.TokenType.CLUE) {
               System.out.printf("%n* %s", el.getName());
               printed = true;
               continue;
            }
         }
      }
      // end of leads
   }
   
   public static int cluesCarried() {
      Investigator[] people = Engine.getPeople();
      Investigator person = people[Engine.getLead()];
      ArrayList<Token> inventory = person.getInventory();
      
      int n = 0;
      for (Token em : inventory) {
         if (em.type == Token.TokenType.CLUE) ++n;
      }
      
      return n;
   }
   
   /****************************************
   * Travel Agent
   ****************************************/
   public static int travelMenu() {
      Location[] places = Engine.getBoard();
      int index = Location.getLocation();
      Location here = places[index];
      
      int[] placesToGo = here.getDestinations(places, index);
      int numOptions = here.numDestinations(places, index);
      System.out.printf("%n======== ======== ======== ======== ");
      System.out.printf("%nTravel Agent");
      System.out.printf("%n======== ======== ======== ======== ");
      
      int i = 1;
      System.out.printf("%nTravel Destinations:");
      for (int el : here.getDestinations(places, index)) {
         System.out.printf("%n%d. %s", i, here.getName(places,el));
         ++i;
      }
      System.out.printf("%n");
      
      int choice;
      do {
         System.out.printf("%nChoose a destination (0 to return): ");
         preventNonInteger();
         choice = input.nextInt() - 1;
      } while (choice >= numOptions);
      
      if (choice < 0) return index;
      int destination = placesToGo[choice];
      
      Engine.useAction();
      return destination;
   }
   
   /****************************************
   * Travel Agent
   ****************************************/
   public static void restAction() {
      Investigator[] people = Engine.getPeople();
      Investigator person = people[Engine.getLead()];
      
      person.restAction(person);
   }
   
   // end of code
}