/****************************************
* Last edit: 4/19/2017
* 
* Represents player-collectible objects
* and location-placed objects
****************************************/

import java.util.ArrayList;
import java.util.Collections;

public class Token {
   enum TokenType {ARTIFACT, ASSET, CONDITION, GATE, CLUE, MONSTER, SKILL, SPELL, TICKET}
   enum AssetType {ALLY, ITEM, SERV, TRINKET}
   enum AssetSubtype {MAGICAL, TOME, WEAPON} // TODO - FINISH LIST
   enum ConditionType {BANE, BOON, DEAL, INJURY, MADNESS} // TODO - FINISH LIST
   enum SpellType {INCANTATION, RITUAL}
   
   // fields
   private String name = "Token";
   private boolean hasReckoning = false;
   private int locationID;
   public TokenType type;
   public AssetType assetType;
   public AssetType assetSubtype;
   public ConditionType conditionType;
   public SpellType spellType;
   
   // constructors
   public Token(TokenType type, String name, int loc) {
      this.type = type;
      this.name = name;
      locationID = loc;
   }
   
   /****************************************
   * Card Shuffler
   ****************************************/
   public void moveIndexUp(ArrayList<Token> list)     {Collections.rotate(list, -1);}
   public void tokenShuffle(ArrayList<Token> list)    {Collections.shuffle(list);}
   
   /****************************************
   * Clue tokens
   ****************************************/
   public void cluesInit(ArrayList<Token> list) {
      for (int i = 1; i <= 36; ++i) {
         list.add(new Token(Token.TokenType.CLUE, "Clue", i));
      }
      tokenShuffle(list);
   }
   
   /****************************************
   * Gate tokens
   ****************************************/
   public void gatesInit(ArrayList<Token> list) {
      list.add(new Token(Token.TokenType.GATE, "San Francisco", 22));
      list.add(new Token(Token.TokenType.GATE, "Arkham", 23));
      list.add(new Token(Token.TokenType.GATE, "Buenos Aires", 24));
      list.add(new Token(Token.TokenType.GATE, "London", 25));
      list.add(new Token(Token.TokenType.GATE, "Rome", 26));
      list.add(new Token(Token.TokenType.GATE, "Istanbul", 27));
      list.add(new Token(Token.TokenType.GATE, "Shanghai", 28));
      list.add(new Token(Token.TokenType.GATE, "Tokyo", 29));
      list.add(new Token(Token.TokenType.GATE, "Sydney", 30));
      tokenShuffle(list);
   }
   
   /****************************************
   * Monster tokens
   ****************************************/
   public void monsterInit(ArrayList<Token> list) {
      for (int i = 1; i <= 34; ++i) {
         list.add(new Token(Token.TokenType.MONSTER, "Monster", i));
      }
   }
   
   
   public String getName() {return name;}
   public TokenType getType() {return type;}
   public int getID(Token token) {return token.locationID;}
   
   public Token getToken(ArrayList<Token> list, int index) {return list.get(index);}
   
   public void setLoc(int newLoc)      {locationID = newLoc;}
   
   @Override
   public String toString() {
      return "" + type + "\\" + getName() + "\\" + locationID;
   }
   
   /****************************************
   * Spawn gates & clues
   ****************************************/
   public void tokenSpawn(Location[] places, 
                           ArrayList<Token> list,
                           int number) {
      int index;
      Location place;
      ArrayList<Token> destination;
      for (int i = 1; i <= number; ++i) {
         index = getID(getToken(list, 0));
         place = places[index];
         destination = place.getInventory();
         tokenMove(list, destination);
         moveIndexUp(list);
         // TODO REMOVE SYSTEM MESSAGE WHEN COMPLETE
         System.out.printf("%nToken appears at: %s", place.getName());
      }
   }
   
   /****************************************
   * Transfer token between inventories
   ****************************************/
   public void tokenMove(ArrayList<Token> origin, ArrayList<Token> target) {
      target.add(origin.remove(0));
   }
}