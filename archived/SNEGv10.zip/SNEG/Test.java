/****************************************
* Last edited: 4/24/2017
* 
* Represents different skill tests
****************************************/

public enum Test {LOR, INF, OBS, STR, WIL}