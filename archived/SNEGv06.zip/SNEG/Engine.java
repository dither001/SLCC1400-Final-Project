/****************************************
* Last edit: 4/22/2017
* 
* creates and runs game objects
****************************************/

import java.util.ArrayList;

public class Engine {
   // fields
   private static final Location board = new Location("", Location.LocType.CITY, 0);
   private static final Location[] world = board.boardInit();
   private static final Investigator nobody = new Investigator("","",0,0,0,0,0,0,0,0);
   private static final Investigator[] investigators = nobody.investigatorInit();
   
   private static final Menu menu = new Menu();
   private static final DiceRoller dice = new DiceRoller();
   private static final TextWrap wrap = new TextWrap();
   private static final EncGeneral enc = new EncGeneral(dice, wrap);
   private static final EncGreen green = new EncGreen(dice, wrap);
   private static final EncOrange orange = new EncOrange(dice, wrap);
   private static final EncPurple purple = new EncPurple(dice, wrap);
   private static final EncResearch research = new EncResearch(dice, wrap);
   private static final Mythos mythos = new Mythos(dice, wrap);
   
   private static final Token meeple = new Token(Token.TokenType.CLUE, "Chit", 0);
   private static ArrayList<Token> clueDeck = new ArrayList<Token>();
   private static ArrayList<Token> gateDeck = new ArrayList<Token>();
   private static ArrayList<Token> monsterDeck = new ArrayList<Token>();
   
   private static int turnCounter = 1;
   private static int leadInvestigator; // index value
   private static int playerLocation; // index value
   
   private static int actions = 0;
   private static int encounters = 0;
   
   // methods
   public static void gameSetup() {
      leadInvestigator = menu.investigatorSelect(investigators);
      playerLocation = (nobody.getLocation(nobody.getPerson(investigators, leadInvestigator)));
      board.updateLocation(playerLocation);
      
      meeple.cluesInit(clueDeck);
      meeple.gatesInit(gateDeck);
      meeple.tokenSpawn(world, clueDeck, 1);
      meeple.tokenSpawn(world, gateDeck, 1);
      // System.out.printf("%d", board.getLocation());
      // getPerson(investigators, leadInvestigator);
      // getLocation(getPerson(investigators, leadInvestigator));
   }
   
   /****************************************
   * Encounter Phase
   ****************************************/
   public static void encounterPhase() {
      boolean hasMonster = false;
      boolean hasClue = false;
      boolean hasGate = false;
      Location here = world[playerLocation];
      ArrayList<Token> contents = here.getInventory();
      Token el;
      for (int i = 0; i < contents.size(); ++i) {
         el = contents.get(i);
         if (el.type == Token.TokenType.CLUE) hasClue = true;
         if (el.type == Token.TokenType.GATE) hasGate = true;
//          if (el.type == Token.TokenType.MONSTER) hasMonster = true;
      }
      
      if (hasClue == true) clueEncounters();
      else localEncounters();
   }
   
   public static void monsterEncounters() {
   }
   
   public static void clueEncounters() {
      research.localEncounter(nobody.getPerson(investigators, leadInvestigator),
                              board.getPlace(world, playerLocation));
   }
   
   public static void gateEncounters() {
   }
   
   public static void localEncounters() {
      switch (playerLocation) {
         case 22: 
         case 23: 
         case 24: green.localEncounter( nobody.getPerson(investigators, leadInvestigator),
                              board.getPlace(world, playerLocation)); break;
         case 25: 
         case 26: 
         case 27: orange.localEncounter( nobody.getPerson(investigators, leadInvestigator),
                              board.getPlace(world, playerLocation)); break;
         case 28: 
         case 29: 
         case 30: purple.localEncounter( nobody.getPerson(investigators, leadInvestigator),
                              board.getPlace(world, playerLocation)); break;
         default: enc.localEncounter( nobody.getPerson(investigators, leadInvestigator),
                              board.getPlace(world, playerLocation)); break;
      }
   }
   
   /****************************************
   * Mythos Phase
   ****************************************/
   public static void mythosPhase() {
      mythos.drawMythos(turnCounter, world, investigators, leadInvestigator,
                  clueDeck, gateDeck);
      ++turnCounter;
      actions = 0;
      encounters = 0;
   }
   
   /****************************************
   * Game round - basic loop of gameplay
   ****************************************/
   public static void gameRound() {
      while (mythos.getDoom() > 0) {
         // main phase
         while (actions < 1) { // WARNING TURN NUMBER OF ACTIONS BACK TO TWO
            System.out.printf("%nUnallocated clues %d", clueDeck.size());
            System.out.printf("%nUnallocated gates %d", gateDeck.size());
            
            int n = playerLocation;
            playerLocation = menu.travelMenu(world, playerLocation);
            if (playerLocation != n) ++actions;
         }
         
         // encounter phase
         while (encounters < 1) {
            encounterPhase();
            ++encounters;
         }
         menu.pressEnter();
         
         // mythos phase
         mythosPhase();
         
         // end of round
      }
   }
   
   /****************************************
   * Main method
   ****************************************/
   public static void main(String[] args) {
      // game setup
      gameSetup();
      gameRound();
   }
}