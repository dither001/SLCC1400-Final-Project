/****************************************
* Last edited: 4/25/2017
* 
* Represents encounter cards
****************************************/

import java.util.ArrayList;

public class Card {
   ArrayList<Card> generalDeck;
   ArrayList<Card> orangeDeck;
   ArrayList<Card> greenDeck;
   ArrayList<Card> purpleDeck;
   
   ArrayList<Card> researchDeck;
   ArrayList<Card> expeditionDeck;
   ArrayList<Card> otherWorldDeck;
   
   // fields
   // constructors
   // methods
}